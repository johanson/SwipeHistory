# SwipeHistory

Emulate macbook/chromebook (two finger) touchpad browser history navigation by abusing vertical scroll. You need to enable vertical scroll from your touchpad settings, otherwise the extension won't work. The sensitivity depends on myriad of settings, often operating system and touchpad drivers.

![Vivir screenshot dark](screenshots/screenshot-1.png?raw=true)

